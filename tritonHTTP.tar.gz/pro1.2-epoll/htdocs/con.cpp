#include <iostream>
#include <time.h>
#include <string.h>

using namespace std;


int main()
{
    char str[256];
    cin>>str;
    cout<<"Content-Type:text/html; charset=utf-8\r\n\r\n";
}