#include <iostream>
#include <time.h>
#include <string.h>
#include <set>
using namespace std;

int main(){
    string s = "172.19.176.249";
    set<string> deny;
    char buf[256];
    FILE *p = fopen(".htaccess", "r");
    char temp[1024];
    fgets(temp,sizeof(temp),p);
    while(!feof(p))
    {
        //printf("%s",temp);
        if(temp[0]=='d'){
            char *str = temp+10;
            int len = strlen(str);
            str[len-1]='\0';
            deny.insert(str);
        }
        temp[0]='\0';
        fgets(temp,sizeof(temp),p);
    }
    fclose(p);
    set<string>::iterator it;
    //for(it = deny.begin();it != deny.end();it++) cout<<*it<<endl;
    //  if((iter = deny.find("0.0.0.0")) != deny.end())
    //  {
    //      cout<<"find it!"<<endl;
    //  }
    if((it = deny.find("0.0.0.00")) != deny.end())
     {
         cout<<"find 0000"<<endl;
     }
     if((it = deny.find(s)) != deny.end())
     {
         cout<<"find 172"<<endl;
     }
    return 0;
}